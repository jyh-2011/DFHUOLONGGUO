import os
import time
print('DFCL-DEV-220501')
print('此类MINECRAFT程序仅娱乐和学习ursina engine，请支持正版')
print('协议(EULA):')
print('不得在任意渠道发布和接收未经DF团队许可发布修改版本')
print('在信任渠道发布时，应得到DF团队的许可')
print('此程序永久开源，不可发布打包为可执行文件的版本')
print('继续则代表您已同意协议')
os.system('PAUSE')
time.sleep(3)
os.system('cls')
for i in range(10):
    print(' |')
    time.sleep(0.1)
    os.system('cls')
    print(' /')
    time.sleep(0.1)
    os.system('cls')
    print(' --')
    time.sleep(0.1)
    os.system('cls')
    print(' \ ')
    time.sleep(0.1)
    os.system('cls')
ask = input('<type play command>')
while ask != 'exit':
    if ask == 'play DFC1':
        os.system('python DFC1.py')
        ask = ''
    elif ask == 'play DFC1-22429':
        os.system('python DFC1-22429.py')
        ask = ''
    elif ask == 'help':
        print('play { GAMEVERSION } like "play DFC1-22429"')
        print('list')
        ask = ''
    elif ask == 'list':
        ask = ''
        print('DFC{ X }-{YEAR[2]}{MOUNTH[2]}{DAY[2]}')
        os.system('dir/s')
    elif ask == 'play DFC1-220501':
        os.system('python DFC1-220501.py')
        ask = ''
    elif ask == 'play DFC1-220502':
        os.system('python DFC1-220502.py')
        ask = ''
    elif ask == 'secret code:!@#$%^&*()_+':
        print('WHY DO YOU KNOW THIS?DO YOU GET THE CODE???')
        print('ENJOY IT(HUAJI)')
        time.sleep(10)
        os.system('python DFC1-10101332.py')
        ask = ''
    else:
        print('unknown command,try help')
        ask = input('<type play command>')