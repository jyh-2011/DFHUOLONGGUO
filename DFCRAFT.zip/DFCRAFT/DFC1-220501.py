from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController


app = Ursina()
# Define a Voxel class.
# By setting the parent to scene and the model to 'cube' it becomes a 3d button.
sky_texture = load_texture('skybox.png')
class Voxel(Button):
    def __init__(self, position=(0,0,0),):
        super().__init__(
            parent = scene,
            position = position,
            model = 'cube',
            origin_y = .5,
            texture = 'brick',
            color = color.white,
            highlight_color = color.light_gray)
    def input(self,key):
        if key == 'escape':
            quit()
        if self.hovered:
            if key == 'right mouse down':
                voxel = Voxel(position=self.position + mouse.normal,)
            if key == 'left mouse down':
                destroy(self)


    

    

for y in range(4):  
    for z in range(25):
        for x in range(25):
            voxel = Voxel(position=(x,y-1,z))

class Sky(Entity):
	def __init__(self):
		super().__init__(
			parent = scene,
			model = 'sphere',
			texture = sky_texture,
			scale = 150,
			double_sided = True)
#def input(key,self):
#        if self.hovered:
#            if key == 'left mouse down':
#                voxel = Voxel(position=self.position + mouse.normal)
    
#            if key == 'right mouse down':
#                destroy(self)


sky = Sky()
player = FirstPersonController()
app.run()