from ursina import *

app = Ursina()
skyb = load_texture('skybox.png')
player = Entity(model='cube', texture = 'brick', scale_y=5)
class Sky(Entity):
	def __init__(self):
		super().__init__(
			parent = scene,
			model = 'sphere',
			texture = skyb,
			scale = 150,
			double_sided = True)
def update():   # update gets automatically called.
    player.x += held_keys['d'] * .1
    player.x -= held_keys['a'] * .1
sky = Sky()
app.run()   # opens a window and starts the game.
