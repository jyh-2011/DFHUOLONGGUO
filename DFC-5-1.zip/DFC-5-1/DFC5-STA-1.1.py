from email.mime import audio
from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
import numpy as np
import random
import RandomMap
import threading
#导入模块



app = Ursina()
#初始化



create_new_world = 0#是否创建世界



try:
	world = np.load("Map.npy")
except:
	print("[DFC]:Create")
	create_new_world = 1	
	world = np.zeros([50,50,50])
#世界是否存在检测


#-----------------models-----------------
blockmodel = 'Models/m.obj'
entitymodel_flower = 'Models/m-flower.obj'
#-----------------block_textures--------------------
blocktexture_grass_block = load_texture('Textures/grass_block.png')
blocktexture_dirt = load_texture('Textures/dirt.png')
blocktexture_stone = load_texture('Textures/stone.png')
blocktexture_deep_stone = load_texture('Textures/deep_stone.png')
blocktexture_iron = load_texture('Textures/iron.png')
blocktexture_gold = load_texture('Textures/gold.png')
blocktexture_diamond = load_texture('Textures/diamond.png')
blocktexture_sand = load_texture('Textures/sand.png')
blocktexture_iron_ore = load_texture('Textures/iron_ore.png')
blocktexture_gold_ore = load_texture('Textures/gold_ore.png')
blocktexture_diamond_ore = load_texture('Textures/diamond_ore.png')
blocktexture_wood = load_texture('Textures/wood.png')
blocktexture_leaf = load_texture('Textures/leaf.png')
blocktexture_leaf_with_flowers = load_texture('Textures/leaf_with_flowers.png')
blocktexture_plank = load_texture('Textures/plank.png')
blocktexture_stone_brick = load_texture('Textures/stone_brick.png')
blocktexture_broken_stone_brick = load_texture('Textures/broken_stone_brick.png')
#--------------------entity_textures-----------------------
entitytexture_blue_flower = load_texture('Textures/blue_flower.png')
#-------------------sky_texture----------------
sky_texture = load_texture('Textures/skybox.png')
#----------------------icons---------------------
icon_grass = load_texture('Textures/blockicon/grass.png')
icon_dirt = load_texture('Textures/blockicon/dirt.png')
icon_stone = load_texture('Textures/blockicon/stone.png')
icon_iron = load_texture('Textures/blockicon/iron.png')
icon_gold = load_texture('Textures/blockicon/gold.png')
icon_diamond = load_texture('Textures/blockicon/diamond.png')
icon_sand = load_texture('Textures/blockicon/sand.png')
icon_plank = load_texture('Textures/blockicon/plank.png')
icon_stone_brick = load_texture('Textures/blockicon/stone_brick.png')
#----------------------other------------------------
background = load_texture('Textures/blockicon/background.png')
block_pick = 1
t = blocktexture_grass_block
i_t = icon_grass
model = blockmodel
#声明变量(材质模型等)



class Inventory(Button):
	def __init__(self,):
		super().__init__(
		parent = camera.ui,
		model = 'quad',
		scale = (.9, .1),
		origin = (-.5, .5),
		position = (-.4,-.25),
		texture = background,
		texture_scale = (9,1),
		color = color.white
			)

class Item_Draw(Button):
	def __init__(self,texture=i_t,position=(-.39,-.26),):
		super().__init__(
		parent = camera.ui,
		model = 'quad',
		scale = ( .08, .08),
		origin = (-.5, .5),
		position = position,
		texture = texture,
		texture_scale = (1,1),
		color = color.white
			)
class Entity_Flower(Button):
    def __init__(self, position=(0,0,0),texture = entitytexture_blue_flower,model = entitymodel_flower):
        super().__init__(
            parent = scene,
            position = position,
            model = model,
            origin_y = .5,
            texture = texture,
            color = color.color(0,0,random.uniform(0.9,1)),
            highlight_color = color.light_gray,)
    #def input(self,key):
        

class Voxel(Button):
    def __init__(self, position=(0,0,0),texture = blocktexture_iron,model = blockmodel):
        super().__init__(
            parent = scene,
            position = position,
            model = model,
            origin_y = .5,
            texture = texture,
            color = color.color(0,0,random.uniform(0.9,1)),
            highlight_color = color.light_gray,)
    def input(self,key):
        global t,model,block_pick,inventory
        if key == 'escape':
            
            quit()
        global entitytexture_blue_flower,entitymodel_flower
        if key == '1':
            t = blocktexture_grass_block
            model = blockmodel
            block_pick = 1
        if key == '2':
            t = blocktexture_dirt
            model = blockmodel
            block_pick = 2
        if key == '3':
            t = blocktexture_stone
            model = blockmodel
            block_pick = 3
        if key == '4':
            t = blocktexture_iron
            model = blockmodel
            block_pick = 4
        if key == '5':
            t = blocktexture_gold
            model = blockmodel
            block_pick = 5
        if key == '6':
            t = blocktexture_diamond
            model = blockmodel
            block_pick = 6
        if key == '7':
            t = blocktexture_sand
            model = blockmodel
            block_pick = 7
        if key == '8':
            t = blocktexture_plank
            model = blockmodel
            block_pick = 15
        if key == '9':
            block_pick = 16
        if self.hovered:
            if key == 'f':
                print('press f')
                pos = self.position + mouse.normal
                flower = Entity_Flower(position = pos,texture=entitytexture_blue_flower,model=entitymodel_flower)
            pass
            if key == 'right mouse down' or key == 'o':
                if block_pick == 1:
                    t = blocktexture_grass_block
                    pos = self.position + mouse.normal
                    voxel = Voxel(position=pos,texture=t,model=model)
                    world[int(pos[0]), int(pos[1]+1), int(pos[2])] = block_pick
                if block_pick == 2:
                    pos = self.position + mouse.normal
                    voxel = Voxel(position=pos,texture=t,model=model)
                    world[int(pos[0]), int(pos[1]+1), int(pos[2])] = block_pick
                if block_pick == 3:
                    pos = self.position + mouse.normal
                    voxel = Voxel(position=pos,texture=t,model=model)
                    world[int(pos[0]), int(pos[1]+1), int(pos[2])] = block_pick
                if block_pick == 4:
                    pos = self.position + mouse.normal
                    voxel = Voxel(position=pos,texture=t,model=model)
                    world[int(pos[0]), int(pos[1]+1), int(pos[2])] = block_pick
                if block_pick == 5:
                    pos = self.position + mouse.normal
                    voxel = Voxel(position=pos,texture=t,model=model)
                    world[int(pos[0]), int(pos[1]+1), int(pos[2])] = block_pick
                if block_pick == 6:
                    pos = self.position + mouse.normal
                    voxel = Voxel(position=pos,texture=t,model=model)
                    world[int(pos[0]), int(pos[1]+1), int(pos[2])] = block_pick
                if block_pick == 7:
                    pos = self.position + mouse.normal
                    voxel = Voxel(position=pos,texture=t,model=model)
                    world[int(pos[0]), int(pos[1]+1), int(pos[2])] = block_pick
                if block_pick == 15:
                    pos = self.position + mouse.normal
                    voxel = Voxel(position=pos,texture=t,model=model)
                    world[int(pos[0]), int(pos[1]+1), int(pos[2])] = block_pick
                if block_pick == 16:
                    a = random.randint(1,10)
                    if a<8:
                        pos = self.position + mouse.normal
                        voxel = Voxel(position=pos,texture=blocktexture_stone_brick,model=model)
                        world[int(pos[0]), int(pos[1]+1), int(pos[2])] = block_pick
                        print(a)
                    else:
                        pos = self.position + mouse.normal
                        voxel = Voxel(position=pos,texture=blocktexture_broken_stone_brick,model=model)
                        world[int(pos[0]), int(pos[1]+1), int(pos[2])] = block_pick+1
            if key == 'left mouse down' or key == 'p':
                pos = self.position
                if world[int(pos[0]), int(pos[1]+1), int(pos[2])] == 11:
                    pass
                else:
                    world[int(pos[0]), int(pos[1]+1), int(pos[2])] = 0
                    destroy(self)
#方块初始化，事件侦测，方块放置和删除，对地图文件编辑

def gametick():
    print("AUTOSAVEON!")
    while True:
        np.save("Map.npy",world)
        print("[DFC]:AutoSave")
        time.sleep(60)
inv_on = True
def update():
    global inventory,inv_on,i_t
    if held_keys['r']: 
        np.save("Map.npy", world)
        print("[DFC]:Save")
    if held_keys['f3']: 
        inv_on = False
        destroy(inventory)
        print("[DFC]:InventoryHide")
    if held_keys['f4']: 
        print("[DFC]:InventoryShow")
        try:
            destroy(inventory)
            inventory = Inventory()
            inv_on = True
            drawitem()
        except:
            inventory = Inventory()
            inv_on = True
            drawitem()
    if held_keys['1']:
        drawitem()
        item1.position = (-.39,-.25)
    if held_keys['2']:
        drawitem()
        item2.position = (-.29,-.25)
    if held_keys['3']:
        drawitem()
        item3.position = (-.19,-.25)
    if held_keys['4']:
        drawitem()
        item4.position = (-.09,-.25)
    if held_keys['5']:
        drawitem()
        item5.position = (.01,-.25)
    if held_keys['6']:
        drawitem()
        item6.position = (.11,-.25)
    if held_keys['7']:
        drawitem()
        item7.position = (.21,-.25)
    if held_keys['8']:
        drawitem()
        item8.position = (.31,-.25)
    if held_keys['9']:
        drawitem()
        item9.position = (.41,-.25)
#其他按键事件侦测




if(create_new_world == 1):
    noice = RandomMap.ReturnRandomMap()
    for z in range(0,25):
        for x in range(0,25):
            if noice[x][z]==4:
                world[x,4,z] = 3
                world[x,5,z] = 3
                world[x,6,z] = 3
                world[x,7,z] = 3
            if noice[x][z]==3:
                world[x,4,z] = 2
                world[x,5,z] = 2
                world[x,6,z] = 1
            if noice[x][z]==2:
                world[x,4,z] = 2
                world[x,5,z] = 1
            if noice[x][z]==1:
                world[x,4,z] = 1
    for z in range(0,25):
        for x in range(0,25):
            world[x,3,z] = 1
    for z in range(0,25):
        for x in range(0,25):
            world[x,2,z] = 2
    for z in range(0,25):
        for x in range(0,25):
            world[x,1,z] = 3
    for z in range(0,25):
        for x in range(0,25):
            world[x,0,z] = 11
    for z in range(0,25):
        for x in range(0,25):
            if noice[z][x]==1:
                world[x,4,z] = 1
                under = [2,3,2,2,2]
                world[x,3,z] = random.choice(under)
            if noice[z][x]==2:
                world[x,4,z] = 2
                world[x,5,z] = 1
                under = [2,3,2,2,2]
                world[x,3,z] = random.choice(under)
            if noice[z][x]==3:
                world[x,4,z] = 2
                world[x,5,z] = 2
                world[x,6,z] = 1
                under = [2,3,2,2,2]
                world[x,3,z] = random.choice(under)
            else:
                pass
    for i in range(0,random.randint(3,6)):
        a = random.randint(1,24)
        b = random.randint(1,24)
        c = random.randint(7,10)
        for j in range(3,c):
            world[a,j,b]=12
        for j in range(a-2,a+3):
            for k in range(b-2,b+3):
                world[j,c,k]=13

    for i in range(0,random.randint(15,20)):
        a = random.randint(1,24)
        b = random.randint(1,24)
        world[a,1,b] = 8
    for i in range(0,random.randint(10,15)):
        a = random.randint(1,24)
        b = random.randint(1,24)
        world[a,1,b] = 9
    for i in range(0,random.randint(3,8)):
        a = random.randint(1,24)
        b = random.randint(1,24)
        world[a,1,b] = 10
    np.save("Map.npy", world)
    t = blocktexture_grass_block
else:
    for x in range(40):
        for y in range(-1,40):
            for z in range(40):
                if world[x,y+1,z]==1:
                    t = blocktexture_grass_block
                if world[x,y+1,z]==2:
                    t = blocktexture_dirt
                if world[x,y+1,z]==3:
                    t = blocktexture_stone
                if world[x,y+1,z]==4:
                    t = blocktexture_iron
                if world[x,y+1,z]==5:
                    t = blocktexture_gold
                if world[x,y+1,z]==6:
                    t = blocktexture_diamond
                if world[x,y+1,z]==7:
                    t = blocktexture_sand
                if world[x,y+1,z]==8:
                    t = blocktexture_iron_ore
                if world[x,y+1,z]==9:
                    t = blocktexture_gold_ore
                if world[x,y+1,z]==10:
                    t = blocktexture_diamond_ore
                if world[x,y+1,z]==11:
                    t = blocktexture_deep_stone
                if world[x,y+1,z]==12:
                    t = blocktexture_wood
                if world[x,y+1,z]==13:
                    t = blocktexture_leaf
                if world[x,y+1,z]==14:
                    t = blocktexture_leaf_with_flowers
                if world[x,y+1,z]==15:
                    t = blocktexture_plank
                if world[x,y+1,z]==16:
                    t = blocktexture_stone_brick
                if world[x,y+1,z]==17:
                    t = blocktexture_broken_stone_brick
                if world[x,y+1,z] != 0:
                    voxel = Voxel(position = (x,y,z), texture = t)
    #flower = Entity_Flower(position=(3,5,3))

    t = blocktexture_grass_block
#创建世界或加载世界



class Sky(Entity):
	def __init__(self):
		super().__init__(
			parent = scene,
			model = 'sphere',
			texture = sky_texture,
			scale = 150,
			double_sided = True)
#天空盒
def drawitem():
    global item1,item2,item3,item4,item5,item6,item7,item8,item9
    try:
        destroy(item1)
        destroy(item2)
        destroy(item3)
        destroy(item4)
        destroy(item5)
        destroy(item6)
        destroy(item7)
        destroy(item8)
        destroy(item9)
    except:
        pass
    item1 = Item_Draw()
    item2 = Item_Draw(position = (-.29,-.26),texture=icon_dirt)
    item3 = Item_Draw(position = (-.19,-.26),texture=icon_stone)
    item4 = Item_Draw(position = (-.09,-.26),texture=icon_iron)
    item5 = Item_Draw(position = (.01,-.26),texture=icon_gold)
    item6 = Item_Draw(position = (.11,-.26),texture=icon_diamond)
    item7 = Item_Draw(position = (.21,-.26),texture=icon_sand)
    item8 = Item_Draw(position = (.31,-.26),texture=icon_plank)
    item9 = Item_Draw(position = (.41,-.26),texture=icon_stone_brick)
if __name__ == "__main__":

    if create_new_world != 1:
        item1,item2,item3,item4,item5,item6,item7,item8,item9 = 0,0,0,0,0,0,0,0,0
        t = threading.Thread(target=gametick)
        t.setDaemon(True)
        t.start()
        player = FirstPersonController()#第一人称玩家主体创建
        sky = Sky()#天空盒
        inventory = Inventory()
        drawitem()
        item1.position = (-.39,-.25)
        app.run()#运行
    else:
        import os
        getid = os.getpid()
        os.system('python Loader.py')
        os.close(getid)