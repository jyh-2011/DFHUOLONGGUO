﻿import numpy
import random
import time,os
e = 0
b = numpy.array([numpy.arange(1,26)]*25)
#print(b)
def two2threeside(a,x,y):
    s = a[x][y]
    if(s==0):
        if(a[x-1][y+1]==-1 or a[x][y+1]==-1 or a[x+1][y+1]==-1 or
        a[x-1][y]==-1 or a[x+1][y]==-1 or
        a[x-1][y-1]==-1 or a[x][y-1]==-1 or a[x+1][y-1]==-1):
            a[x][y]=1
def two2threeinside(a,x,y,n):
    s=a[x][y]
    if(s==n):
        if(a[x-1][y+1]==0):
            a[x-1][y+1]=n+1
        if(a[x][y+1]==0):
            a[x][y+1]=2
        if(a[x+1][y+1]==0):
            a[x+1][y+1]=n+1
        if(a[x-1][y]==0):
            a[x-1][y]=n+1
        if(a[x+1][y]==0):
            a[x+1][y]=n+1
        if(a[x-1][y-1]==0):
            a[x-1][y-1]=n+1
        if(a[x][y-1]==0):
            a[x][y-1]=n+1
        if(a[x+1][y-1]==0):
            a[x+1][y-1]=n+1
for i in range(0,25):
    for j in range(0,25):
        a = random.randint(0,1)
        if a == 0:
            b[i,j]=-1
        else:
            b[i,j]=0
for k in range(1):
    for i in range(1,24):
        for j in range(1,24):
            if b[i][j]==-1:
                if b[i-1][j+1]==0:
                    e=e+1
                if b[i-1][j]==0:
                    e=e+1
                if b[i-1][j-1]==0:
                    e=e+1
                if b[i][j+1]==0:
                    e=e+1
                if b[i][j-1]==0:
                    e=e+1
                if b[i+1][j+1]==0:
                    e=e+1
                if b[i+1][j]==0:
                    e=e+1
                if b[i+1][j-1]==0:
                    e=e+1
                if e > 4:
                    b[i][j]=0
                    e = 0
                else:
                    pass
                    #b[i][j]=0
                    #e = 0
            else:
                if b[i-1][j+1]==-1:
                    e=e+1
                if b[i-1][j]==-1:
                    e=e+1
                if b[i-1][j-1]==-1:
                    e=e+1
                if b[i][j+1]==-1:
                    e=e+1
                if b[i][j-1]==-1:
                    e=e+1
                if b[i+1][j+1]==-1:
                    e=e+1
                if b[i+1][j]==-1:
                    e=e+1
                if b[i+1][j-1]==-1:
                    e=e+1
                if e > 5:
                    b[i][j]=-1                        
                    e = 0
                else:
                    pass
                    #b[i][j]=1
                    #e = 0
#print(b)
for i in range(1,24):
    for j in range(1,24):
        two2threeside(b,i,j)
        pass
for i in range(1,24):
    for j in range(1,24):
        two2threeinside(b,i,j,1)
        pass
for i in range(1,24):
    for j in range(1,24):
        two2threeinside(b,i,j,2)
        pass
for i in range(1,24):
    for j in range(1,24):
        two2threeinside(b,i,j,3)
        pass
def ReturnRandomMap():
    return b
if __name__ == '__main__':
    c = numpy.array2string(b)
    d = str(c.replace('-1',' 0'))
    print(d+'\n')
