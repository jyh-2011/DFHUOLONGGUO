from email.mime import audio
from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
import random

app = Ursina()
# Define a Voxel class.
# By setting the parent to scene and the model to 'cube' it becomes a 3d button.
sky_texture = load_texture('skybox.png')
blocktexture_grass = load_texture('blocks/grass.png')
blocktexture_stone = load_texture('blocks/stone.png')
blocktexture_dirt = load_texture('blocks/dirt.png')
t = blocktexture_grass
#b_m = Audio('MoogCity.mp3',loop = True,autoplay = True)
class Voxel(Button):
    def __init__(self, position=(0,0,0),texture = blocktexture_grass):
        super().__init__(
            parent = scene,
            position = position,
            model = 'blocks/m.obj',
            origin_y = .5,
            texture = texture,
            color = color.color(0,0,random.uniform(0.9,1)),
            highlight_color = color.light_gray,)
    def input(self,key):
        global t
        if key == 'escape':
            quit()
        if key == '1':
            t = blocktexture_grass
        if key == '2':
            t = blocktexture_stone
        if key == '3':
            t = blocktexture_dirt
        if self.hovered:
            if key == 'right mouse down':
                voxel = Voxel(position=self.position + mouse.normal,texture=t)
            if key == 'left mouse down':
                destroy(self)


    

    


for z in range(25):
    for x in range(25):
        voxel = Voxel(position=(x,2,z),texture=blocktexture_grass)
for z in range(25):
    for x in range(25):
        voxel = Voxel(position=(x,1,z),texture=blocktexture_dirt)
for z in range(25):
    for x in range(25):
        voxel = Voxel(position=(x,0,z),texture=blocktexture_stone)
ar = random.randint(10,25)
br = random.randint(10,25)
cr = random.randint(2,10)
print(ar)
print(br)

for r in range(cr,ar):
    for r2 in range(2,br):
        voxel = Voxel(position=(r,3,r2),texture=blocktexture_stone)
ar = random.randint(10,ar-1)
br = random.randint(10,br-1)
for r in range(cr,ar):
    for r2 in range(2,br):
        voxel = Voxel(position=(r,4,r2),texture=blocktexture_stone)
ar = random.randint(5,ar-1)
br = random.randint(5,br-1)
for r in range(cr,ar):
    for r2 in range(2,br):
        voxel = Voxel(position=(r,5,r2),texture=blocktexture_stone)

class Sky(Entity):
	def __init__(self):
		super().__init__(
			parent = scene,
			model = 'sphere',
			texture = sky_texture,
			scale = 150,
			double_sided = True)
#def input(key,self):
#        if self.hovered:
#            if key == 'left mouse down':
#                voxel = Voxel(position=self.position + mouse.normal)
    
#            if key == 'right mouse down':
#                destroy(self)


sky = Sky()
player = FirstPersonController()
app.run()
#一位编程学习者
#ursina引擎忠实粉丝
#jyh-2011.github.io/DFHOULONGGUO/
