import os
print("[DFC]:Restart")
os.system('python DFC5-STA-1.0.py')
