#火龙果世界5 Dev4
#程序启动模块

#导入模块
import os
import time

#显示协议
print('DFC5-STA-1.0')
print('此类MINECRAFT程序仅娱乐和学习ursina engine，请支持正版')
print('协议(EULA):')
print('不得在任意渠道发布和接收未经DF团队许可发布修改版本')
print('在信任渠道发布时，应得到DF团队的许可')
print('此程序永久开源，不可发布打包为可执行文件的版本')
print('继续则代表您已同意协议')
os.system('PAUSE')

#加载动画
time.sleep(1)
os.system('cls')
for i in range(5):
    print(' |')
    time.sleep(0.1)
    os.system('cls')
    print(' /')
    time.sleep(0.1)
    os.system('cls')
    print(' --')
    time.sleep(0.1)
    os.system('cls')
    print(' \ ')
    time.sleep(0.1)
    os.system('cls')

#启动成功提醒
print('游戏启动成功！')
print('请等待游戏窗口出现')
time.sleep(1)

#启动主程序
os.system('python DFC5-STA-1.0.py')
ask = ''

#关闭提醒
print('感谢您的游玩！')
print('更多内容请访问dragonfruitcloud.xyz')
time.sleep(3)
