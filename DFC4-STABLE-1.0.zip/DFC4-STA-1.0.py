from email.mime import audio
from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
import numpy as np
import random
import RandomMap
#导入模块



app = Ursina()
#初始化



create_new_world = 0#是否创建世界



try:
	world = np.load("Map.npy")
except:
	print("[DFC]:Create")
	create_new_world = 1	
	world = np.zeros([50,50,50])
#世界是否存在检测



block_pick = 1
blockmodel = 'TEXTURE_AND_MODEL/m.obj'
blocktexture_grass = load_texture('TEXTURE_AND_MODEL/grass.png')
blocktexture_dirt = load_texture('TEXTURE_AND_MODEL/dirt.png')
blocktexture_stone = load_texture('TEXTURE_AND_MODEL/stone.png')
blocktexture_deep_stone = load_texture('TEXTURE_AND_MODEL/deep_stone.png')
blocktexture_iron = load_texture('TEXTURE_AND_MODEL/iron.png')
blocktexture_gold = load_texture('TEXTURE_AND_MODEL/gold.png')
blocktexture_diamond = load_texture('TEXTURE_AND_MODEL/diamond.png')
blocktexture_sand = load_texture('TEXTURE_AND_MODEL/sand.png')
blocktexture_iron_ore = load_texture('TEXTURE_AND_MODEL/iron_ore.png')
blocktexture_gold_ore = load_texture('TEXTURE_AND_MODEL/gold_ore.png')
blocktexture_diamond_ore = load_texture('TEXTURE_AND_MODEL/diamond_ore.png')
sky_texture = load_texture('TEXTURE_AND_MODEL/skybox.png')
icon_grass = load_texture('TEXTURE_AND_MODEL/blockicon/grass.png')
icon_dirt = load_texture('TEXTURE_AND_MODEL/blockicon/dirt.png')
icon_stone = load_texture('TEXTURE_AND_MODEL/blockicon/stone.png')
icon_iron = load_texture('TEXTURE_AND_MODEL/blockicon/iron.png')
icon_gold = load_texture('TEXTURE_AND_MODEL/blockicon/gold.png')
icon_diamond = load_texture('TEXTURE_AND_MODEL/blockicon/diamond.png')
icon_sand = load_texture('TEXTURE_AND_MODEL/blockicon/sand.png')
t = blocktexture_grass
i_t = icon_grass
model = blockmodel
#声明变量(材质模型等)



class Inventory(Button):
	def __init__(self,texture = i_t):
		super().__init__(
		parent = camera.ui,
		model = 'quad',
		scale = (.1, .1),
		origin = (-.5, .5),
		position = (.40,.40),
		texture = texture,
		texture_scale = (1,1),
		color = color.white
			)
class Voxel(Button):
    def __init__(self, position=(0,0,0),texture = blocktexture_iron,model = blockmodel):
        super().__init__(
            parent = scene,
            position = position,
            model = model,
            origin_y = .5,
            texture = texture,
            color = color.color(0,0,random.uniform(0.9,1)),
            highlight_color = color.light_gray,)
    def input(self,key):
        global t,model,block_pick,inventory
        if key == 'escape':
            quit()
        if key == '1':
            t = blocktexture_grass
            model = blockmodel
            block_pick = 1
        if key == '2':
            t = blocktexture_dirt
            model = blockmodel
            block_pick = 2
        if key == '3':
            t = blocktexture_stone
            model = blockmodel
            block_pick = 3
        if key == '4':
            t = blocktexture_iron
            model = blockmodel
            block_pick = 4
        if key == '5':
            t = blocktexture_gold
            model = blockmodel
            block_pick = 5
        if key == '6':
            t = blocktexture_diamond
            model = blockmodel
            block_pick = 6
        if key == '7':
            t = blocktexture_sand
            model = blockmodel
            block_pick = 7
        if self.hovered:
            if key == 'right mouse down' or key == 'o':
                if block_pick == 1:
                    pos = self.position + mouse.normal
                    voxel = Voxel(position=pos,texture=t,model=model)
                    world[int(pos[0]), int(pos[1]+1), int(pos[2])] = block_pick
                if block_pick == 2:
                    pos = self.position + mouse.normal
                    voxel = Voxel(position=pos,texture=t,model=model)
                    world[int(pos[0]), int(pos[1]+1), int(pos[2])] = block_pick
                if block_pick == 3:
                    pos = self.position + mouse.normal
                    voxel = Voxel(position=pos,texture=t,model=model)
                    world[int(pos[0]), int(pos[1]+1), int(pos[2])] = block_pick
                if block_pick == 4:
                    pos = self.position + mouse.normal
                    voxel = Voxel(position=pos,texture=t,model=model)
                    world[int(pos[0]), int(pos[1]+1), int(pos[2])] = block_pick
                if block_pick == 5:
                    pos = self.position + mouse.normal
                    voxel = Voxel(position=pos,texture=t,model=model)
                    world[int(pos[0]), int(pos[1]+1), int(pos[2])] = block_pick
                if block_pick == 6:
                    pos = self.position + mouse.normal
                    voxel = Voxel(position=pos,texture=t,model=model)
                    world[int(pos[0]), int(pos[1]+1), int(pos[2])] = block_pick
                if block_pick == 7:
                    pos = self.position + mouse.normal
                    voxel = Voxel(position=pos,texture=t,model=model)
                    world[int(pos[0]), int(pos[1]+1), int(pos[2])] = block_pick
            if key == 'left mouse down' or key == 'p':
                pos = self.position
                if world[int(pos[0]), int(pos[1]+1), int(pos[2])] == 11:
                    pass
                else:
                    world[int(pos[0]), int(pos[1]+1), int(pos[2])] = 0
                    destroy(self)
#方块初始化，事件侦测，方块放置和删除，对地图文件编辑


inv_on = True
def update():
    global inventory,inv_on,i_t
    if held_keys['r']: 
        np.save("Map.npy", world)
        print("[DFC]:Save")
    if held_keys['f3']: 
        inv_on = False
        destroy(inventory)
        print("[DFC]:Hide")
    if held_keys['f4']: 
        print("[DFC]:Show")
        try:
            destroy(inventory)
            inventory = Inventory(texture=i_t)
            inv_on = True
        except:
            inventory = Inventory(texture=i_t)
            inv_on = True
    if held_keys['1']:
        i_t = icon_grass
        if(inv_on):
            try:
                destroy(inventory)
                inventory = Inventory(texture=i_t)
            except:
                inventory = Inventory(texture=i_t)
    if held_keys['2']:
        i_t = icon_dirt
        if(inv_on):
            try:
                destroy(inventory)
                inventory = Inventory(texture=i_t)
            except:
                inventory = Inventory(texture=i_t)
    if held_keys['3']:
        i_t = icon_stone
        if(inv_on):
            try:
                destroy(inventory)
                inventory = Inventory(texture=i_t)
            except:
                inventory = Inventory(texture=i_t)
    if held_keys['4']:
        i_t = icon_iron
        if(inv_on):
            try:
                destroy(inventory)
                inventory = Inventory(texture=i_t)
            except:
                inventory = Inventory(texture=i_t)
    if held_keys['5']:
        i_t = icon_gold
        if(inv_on):
            try:
                destroy(inventory)
                inventory = Inventory(texture=i_t)
            except:
                inventory = Inventory(texture=i_t)
    if held_keys['6']:
        i_t = icon_diamond
        if(inv_on):
            try:
                destroy(inventory)
                inventory = Inventory(texture=i_t)
            except:
                inventory = Inventory(texture=i_t)
    if held_keys['7']:
        i_t = icon_sand
        if(inv_on):
            try:
                destroy(inventory)
                inventory = Inventory(texture=i_t)
            except:
                inventory = Inventory(texture=i_t)
#其他按键事件侦测




if(create_new_world == 1):
    noice = RandomMap.ReturnRandomMap()
    for z in range(0,25):
        for x in range(0,25):
            #voxel = Voxel(position=(x,2,z),texture=blocktexture_grass,model=blockmodel)
            world[x,3,z] = 1
    for z in range(0,25):
        for x in range(0,25):
            #voxel = Voxel(position=(x,1,z),texture=blocktexture_dirt,model=blockmodel)
            world[x,2,z] = 2
    for z in range(0,25):
        for x in range(0,25):
            #voxel = Voxel(position=(x,0,z),texture=blocktexture_stone,model=blockmodel)
            world[x,1,z] = 3
    for z in range(0,25):
        for x in range(0,25):
            #voxel = Voxel(position=(x,-1,z),texture=blocktexture_deep_stone,model=blockmodel)
            world[x,0,z] = 11
    for z in range(0,25):
        for x in range(0,25):
            if noice[z][x]==1:
                #voxel = Voxel(position=(x,3,z),texture=blocktexture_grass,model=blockmodel)
                world[x,4,z] = 1
                under = [2,3,2,2,2]
                world[x,3,z] = random.choice(under)
            else:
                pass
    for i in range(0,15):
        a = random.randint(1,24)
        b = random.randint(1,24)
        #voxel = Voxel(position=(a,0,b),texture=blocktexture_iron_ore,model=blockmodel)
        world[a,1,b] = 8
    for i in range(0,10):
        a = random.randint(1,24)
        b = random.randint(1,24)
        #voxel = Voxel(position=(a,0,b),texture=blocktexture_gold_ore,model=blockmodel)
        world[a,1,b] = 9
    for i in range(0,5):
        a = random.randint(1,24)
        b = random.randint(1,24)
        #voxel = Voxel(position=(a,0,b),texture=blocktexture_diamond_ore,model=blockmodel)
        world[a,1,b] = 10
    np.save("Map.npy", world)
    t = blocktexture_grass
else:
    for x in range(40):
        for y in range(-1,40):
            for z in range(40):
                if world[x,y+1,z]==1:
                    t = blocktexture_grass
                if world[x,y+1,z]==2:
                    t = blocktexture_dirt
                if world[x,y+1,z]==3:
                    t = blocktexture_stone
                if world[x,y+1,z]==4:
                    t = blocktexture_iron
                if world[x,y+1,z]==5:
                    t = blocktexture_gold
                if world[x,y+1,z]==6:
                    t = blocktexture_diamond
                if world[x,y+1,z]==7:
                    t = blocktexture_sand
                if world[x,y+1,z]==8:
                    t = blocktexture_iron_ore
                if world[x,y+1,z]==9:
                    t = blocktexture_gold_ore
                if world[x,y+1,z]==10:
                    t = blocktexture_diamond_ore
                if world[x,y+1,z]==11:
                    t = blocktexture_deep_stone
                if world[x,y+1,z] != 0:
                    voxel = Voxel(position = (x,y,z), texture = t)

    t = blocktexture_grass
#创建世界或加载世界



class Sky(Entity):
	def __init__(self):
		super().__init__(
			parent = scene,
			model = 'sphere',
			texture = sky_texture,
			scale = 150,
			double_sided = True)
#天空盒

if __name__ == "__main__":

    if create_new_world != 1:
        player = FirstPersonController()#第一人称玩家主体创建
        sky = Sky()#天空盒
        inventory = Inventory()
        app.run()#运行
    else:
        import os
        getid = os.getpid()
        os.system('python Loader.py')
        os.close(getid)