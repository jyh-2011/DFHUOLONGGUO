import os
os.system('python DFC4-STA-1.0.py')