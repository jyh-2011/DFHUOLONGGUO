﻿import numpy
import random
import time,os
e = 0
b = numpy.array([numpy.arange(1,26)]*25)
#print(b)
for i in range(0,25):
    for j in range(0,25):
        a = random.randint(0,1)
        if a == 0:
            b[i,j]=0
        else:
            b[i,j]=1
for k in range(1):
    for i in range(1,24):
        for j in range(1,24):
            if b[i][j]==0:
                if b[i-1][j+1]==1:
                    e=e+1
                if b[i-1][j]==1:
                    e=e+1
                if b[i-1][j-1]==1:
                    e=e+1
                if b[i][j+1]==1:
                    e=e+1
                if b[i][j-1]==1:
                    e=e+1
                if b[i+1][j+1]==1:
                    e=e+1
                if b[i+1][j]==1:
                    e=e+1
                if b[i+1][j-1]==1:
                    e=e+1
                if e > 4:
                    b[i][j]=1
                    e = 0
                else:
                    pass
                    #b[i][j]=0
                    #e = 0
            else:
                if b[i-1][j+1]==0:
                    e=e+1
                if b[i-1][j]==0:
                    e=e+1
                if b[i-1][j-1]==0:
                    e=e+1
                if b[i][j+1]==0:
                    e=e+1
                if b[i][j-1]==0:
                    e=e+1
                if b[i+1][j+1]==0:
                    e=e+1
                if b[i+1][j]==0:
                    e=e+1
                if b[i+1][j-1]==0:
                    e=e+1
                if e > 5:
                    b[i][j]=0                        
                    e = 0
                else:
                    pass
                    #b[i][j]=1
                    #e = 0
def ReturnRandomMap():
    return b
if __name__ == '__main__':
    c = numpy.array2string(b)
    d = str(c.replace('0','■'))
    d = d.replace('1','.')
    print(d+'\n')
